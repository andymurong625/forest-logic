export default { base: './', build: { target: 'safari12', assetsInlineLimit: 0 } };
