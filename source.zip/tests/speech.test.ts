import test from 'node:test';
import assert from 'node:assert/strict';
import {speak,stopSpeech,recordings} from '../src/speech';
import {bank} from '../src/data';
class FakeAudio {
 static instance:FakeAudio;src='';preload='';onended:(()=>void)|null=null;onerror:(()=>void)|null=null;plays:string[]=[];paused=false;reject=false;
 constructor(){FakeAudio.instance=this;}
 pause(){this.paused=true;}
 play(){this.paused=false;this.plays.push(this.src);return this.reject?Promise.reject(Error('blocked')):Promise.resolve();}
}
Object.assign(globalThis,{Audio:FakeAudio,window:{},document:{body:{appendChild:()=>{}}}});
test('all question prompts, success messages, demos and hints have recording IDs',()=>{
 for(const q of bank){for(const key of ['prompt','success','demo','hint1','hint2','hint3'])assert.ok(recordings[`${q.id}:${key}`]);if(q.mode!=='pick')assert.ok(recordings[`${q.id}:try-again`]);}
 assert.equal(recordings.welcome,recordings['voice-test']);
});
test('queue uses one audio element and interruption prevents old queue restarting',()=>{
 speak(['welcome','shadow-1-0:prompt'],'',true);const a=FakeAudio.instance;
 assert.ok(a.src.endsWith(recordings.welcome));const oldEnd=a.onended!;
 oldEnd();assert.ok(a.src.endsWith(recordings['shadow-1-0:prompt']));
 speak('finish','',true);assert.equal(FakeAudio.instance,a);oldEnd();assert.ok(a.src.endsWith(recordings.finish));
 stopSpeech();assert.equal(a.paused,true);assert.equal(a.onended,null);
});
test('muting never starts playback and missing recordings show an explicit warning',()=>{
 const a=FakeAudio.instance;const count=a.plays.length;speak('welcome','',false);assert.equal(a.plays.length,count);
 let warning='';speak('missing','',true,m=>warning=m);assert.match(warning,/暂未准备好/);assert.equal(a.plays.length,count);
});
test('blocked play reports a retry message; stale rejection is ignored',async()=>{
 const a=FakeAudio.instance;a.reject=true;const warnings:string[]=[];
 speak('welcome','',true,m=>warnings.push(m));stopSpeech();await Promise.resolve();assert.equal(warnings.length,0);
 speak('welcome','',true,m=>warnings.push(m));await Promise.resolve();assert.equal(warnings.length,1);a.reject=false;
});
