import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
const source=readFileSync(new URL('../scripts/build-sw.mjs',import.meta.url),'utf8');
// Execute the generated service-worker template with a real Request/Response API.
function worker(){
 const template=source.slice(source.indexOf('`const PREFIX')+1,source.indexOf('`);',source.indexOf('`const PREFIX'))).replace('${version}','test-version').replace('${JSON.stringify(assets)}',JSON.stringify(['./index.html','./assets/app.js','./']));
 const listeners:Record<string,Function>={};const entries=new Map<string,Response>();const scope='https://example.test/forest/';const messages:any[]=[];const opts:any[]=[];
 const cache={async addAll(paths:string[]){for(const p of paths)entries.set(new URL(p,scope).href,new Response(p.endsWith('.js')?'console.log("offline")':'<html>forest</html>',{headers:{'Vary':'Origin'}}));},async put(url:URL,res:Response){entries.set(String(url),res)},async match(req:Request|URL,options?:any){opts.push(options);const url=req instanceof Request?req.url:String(req);if(req instanceof Request&&req.headers.has('Origin')&&!options?.ignoreVary)return undefined;return entries.get(url)?.clone();}};
 const context={URL,Request,Response,Headers,fetch:async()=>{throw Error('offline')},caches:{open:async()=>cache,keys:async()=>['other-app-cache'],delete:async()=>{throw Error('must not delete other apps')}},self:{registration:{scope},location:{origin:'https://example.test'},addEventListener:(name:string,fn:Function)=>listeners[name]=fn,clients:{claim:async()=>{},matchAll:async()=>[{postMessage:(m:any)=>messages.push(m)}]}}};
 vm.runInNewContext(template,context);return {listeners,entries,scope,messages,opts};
}
async function lifecycle(w:ReturnType<typeof worker>,name:string){let pending:Promise<any>=Promise.resolve();w.listeners[name]({waitUntil:(p:Promise<any>)=>pending=p});await pending;}
test('offline cache completes atomically, announces readiness and preserves other apps',async()=>{const w=worker();await lifecycle(w,'install');assert.ok(w.entries.has(w.scope+'__cache_ready__'));await lifecycle(w,'activate');assert.equal(w.messages[0].type,'CACHE_READY');});
test('cached module still loads offline when request Origin differs from precache',async()=>{const w=worker();await lifecycle(w,'install');let result:Promise<Response>|undefined;w.listeners.fetch({request:new Request(w.scope+'assets/app.js',{headers:{Origin:'https://example.test'}}),respondWith:(p:Promise<Response>)=>result=p});assert.equal(await (await result!).text(),'console.log("offline")');assert.equal(w.opts.at(-1).ignoreVary,true);});
test('worker does not intercept cross-origin resources',()=>{const w=worker();let intercepted=false;w.listeners.fetch({request:new Request('https://another.test/a'),respondWith:()=>intercepted=true});assert.equal(intercepted,false);});

test('cached audio serves Safari byte ranges offline',async()=>{
 const w=worker();await lifecycle(w,'install');w.entries.set(w.scope+'audio/test.m4a',new Response('0123456789',{headers:{'Content-Type':'audio/mp4'}}));
 for(const [range,status,body,contentRange] of [['bytes=0-1',206,'01','bytes 0-1/10'],['bytes=7-',206,'789','bytes 7-9/10'],['bytes=-3',206,'789','bytes 7-9/10'],['bytes=99-',416,'','bytes */10']] as const){
  let pending:Promise<Response>|undefined;w.listeners.fetch({request:new Request(w.scope+'audio/test.m4a',{headers:{Range:range}}),respondWith:(p:Promise<Response>)=>pending=p});const res=await pending!;assert.equal(res.status,status);assert.equal(await res.text(),body);assert.equal(res.headers.get('Content-Range'),contentRange);
 }
});
