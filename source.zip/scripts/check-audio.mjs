import {readFile,stat} from 'node:fs/promises';
const plan=JSON.parse(await readFile('voice-lines.json','utf8'));
const map=JSON.parse(await readFile('src/recordings.json','utf8'));
for(const line of plan.lines){
 const path='public/audio/'+line.file;
 const info=await stat(path).catch(()=>null);if(!info||info.size<1000)throw Error('Missing or empty recording: '+path);
 const bytes=await readFile(path);if(bytes.subarray(4,8).toString()!=='ftyp')throw Error('Not an MP4 audio file: '+path);
 for(const id of line.ids)if(map[id]!=='audio/'+line.file)throw Error('Stale cue map: '+id);
}
console.log(`Verified ${plan.lines.length} packaged Serena recordings and ${Object.keys(map).length} cue mappings`);
