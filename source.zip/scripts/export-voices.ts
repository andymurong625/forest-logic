import {bank} from '../src/data';
import {labels,kinds} from '../src/types';
import {writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const byId:Record<string,string>={
 welcome:'你好呀！我是小兔。欢迎来到森林逻辑乐园！我们一起去发现小秘密吧。',
 resume:'欢迎回来，我们接着玩吧。',
 finish:'准备好啦！谢谢你帮忙，一起野餐吧！',
 'voice-test':'你好呀！我是小兔。欢迎来到森林逻辑乐园！我们一起去发现小秘密吧。'
};
for(const k of kinds)byId[`free-${k}`]=`一起来玩${labels[k].name}。`;
for(const q of bank){byId[`${q.id}:prompt`]=q.prompt;byId[`${q.id}:success`]=q.explanation;byId[`${q.id}:demo`]=q.demo;q.hints.forEach((t,i)=>byId[`${q.id}:hint${i+1}`]=t);if(q.mode!=='pick')byId[`${q.id}:try-again`]=q.mode==='order'?'现在轮到你啦。按刚才的顺序，再试一次。':'现在轮到你啦。点物品，再点篮子，把符合要求的都放进去。';}
const unique=new Map<string,{file:string,text:string,ids:string[]}>();
for(const [id,text] of Object.entries(byId)){if(!unique.has(text))unique.set(text,{file:createHash('sha256').update(text).digest('hex').slice(0,16)+'.m4a',text,ids:[]});unique.get(text)!.ids.push(id);}
const lines=[...unique.values()];
writeFileSync('voice-lines.json',JSON.stringify({model:'Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice',speaker:'Serena',lines},null,2));
const recordings=Object.fromEntries(lines.flatMap(l=>l.ids.map(id=>[id,'audio/'+l.file])));
writeFileSync('src/recordings.json',JSON.stringify(recordings,null,2));
console.log(`${Object.keys(byId).length} cue IDs, ${lines.length} unique recordings`);
