import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve, extname, sep } from 'node:path';
const root=fileURLToPath(new URL('../dist/',import.meta.url));
const port=Number(process.env.PORT||4173);
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json','.json':'application/json','.m4a':'audio/mp4'};
const server=createServer(async(req,res)=>{
 try{
  const path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  let target=resolve(root,'.'+path);
  if(target!==root.slice(0,-1)&&!target.startsWith(root.endsWith(sep)?root:root+sep)){res.writeHead(403);res.end();return;}
  if((await stat(target)).isDirectory())target=resolve(target,'index.html');
  const body=await readFile(target);
  if(req.headers.range&&extname(target)==='.m4a'){
   const match=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);let start=0,end=body.length-1;
   if(match){if(match[1]){start=Number(match[1]);if(match[2])end=Math.min(Number(match[2]),end);}else if(match[2])start=Math.max(0,body.length-Number(match[2]));}
   if(!match||(!match[1]&&!match[2])||start>end||start>=body.length){res.writeHead(416,{'Content-Range':`bytes */${body.length}`});res.end();return;}
   res.writeHead(206,{'Content-Type':'audio/mp4','Content-Range':`bytes ${start}-${end}/${body.length}`,'Content-Length':end-start+1,'Accept-Ranges':'bytes'});res.end(body.subarray(start,end+1));return;
  }
  res.writeHead(200,{'Content-Type':mime[extname(target)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(body);
 }catch{res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});res.end('文件不存在');}
});
server.on('error',error=>{console.error(`无法启动预览：${error.message}。可以用 PORT=4180 换一个端口。`);process.exitCode=1;});
server.listen(port,'127.0.0.1',()=>console.log(`森林逻辑乐园已启动： http://localhost:${port}/\n保持此窗口打开。按 Control+C 停止。\n此地址仅用于这台电脑预览；iPad 安装请阅读《安装说明》。`));
