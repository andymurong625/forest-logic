#!/bin/zsh
cd -- "$(dirname -- "$0")"
forest_node="$(command -v node)"
if [[ -z "$forest_node" && -x /Users/andymurong/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node ]]; then
  forest_node=/Users/andymurong/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node
fi
if [[ -z "$forest_node" ]]; then
  echo '本地预览需要 Node.js 20 或更新版本。部署网页不需要在 iPad 安装 Node.js。'
  read -r '?按回车关闭'
  exit 1
fi
"$forest_node" scripts/serve.mjs
