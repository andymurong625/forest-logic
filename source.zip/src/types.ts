export const kinds = ['shadow','opposite','animal','pattern','classify','sequence','different','reason'] as const;
export type Kind = typeof kinds[number];
export type Level = 1 | 2 | 3;
export type Picture = { icon: string; color?: string; shape?: string; detail?: string; shadow?: boolean; flip?: boolean; count?: number };
export type Choice = { id: string; label: string; picture: Picture };
export type Question = { id: string; kind: Kind; level: Level; title: string; prompt: string; mode: 'pick'|'collect'|'order'; reference?: Picture; strip?: (Picture|null)[]; choices: Choice[]; answer: string[]; hints: [string,string,string]; explanation: string; demo: string };
export const labels: Record<Kind, {name:string; subtitle:string; icon:string; color:string}> = {
 shadow:{name:'影子配对',subtitle:'发现轮廓的小秘密',icon:'rabbit',color:'#eec96d'},
 opposite:{name:'反义词关联',subtitle:'找找相反的样子',icon:'umbrella',color:'#e9aea1'},
 animal:{name:'动物特征',subtitle:'认识森林好朋友',icon:'cat',color:'#b4cca6'},
 pattern:{name:'颜色规律',subtitle:'让颜色排好队',icon:'train',color:'#a8cbd5'},
 classify:{name:'分类归纳',subtitle:'做个整理小能手',icon:'basket',color:'#e8b887'},
 sequence:{name:'顺序排列',subtitle:'先做什么，再做什么',icon:'flower',color:'#c9bedf'},
 different:{name:'找不同',subtitle:'睁大发现的眼睛',icon:'star',color:'#e9ca85'},
 reason:{name:'线索推理',subtitle:'跟着线索找答案',icon:'house',color:'#a7c5b7'}
};
