import manifest from './recordings.json';
export const recordings:Record<string,string>=manifest;
let player:HTMLAudioElement|null=null;
let generation=0;
export function stopSpeech(){
 generation++;
 if(player){player.onended=null;player.onerror=null;player.pause();}
 // Stop any speech left over from an older app version.
 if('speechSynthesis' in window)window.speechSynthesis.cancel();
}
export function speechStatus(){return 'Serena · 温柔中文配音 · 音频随游戏保存到设备';}
export function speak(id:string|string[],_text:string,enabled:boolean,onFailure?:(message:string)=>void){
 stopSpeech();if(!enabled)return;
 const ticket=generation;
 const queue=(Array.isArray(id)?id:[id]).map(key=>recordings[key]);
 if(queue.some(file=>!file)){onFailure?.('这段声音暂未准备好，请参考图片和文字。');return;}
 // Reuse the element first played in the tap handler, including queued introductions on iOS.
 if(!player){player=new Audio();player.preload='auto';player.id='narration-audio';player.hidden=true;document.body.appendChild(player);}
 const audio=player;let index=0;
 const fail=()=>{if(ticket!==generation)return;audio.onended=null;audio.onerror=null;onFailure?.('声音未播放，请点小喇叭重试。若刚更新过游戏，请联网等待缓存完成。');};
 const next=()=>{
  if(ticket!==generation)return;
  if(index>=queue.length){audio.onended=null;audio.onerror=null;return;}
  audio.src=(import.meta.env?.BASE_URL||'./')+queue[index++];
  audio.onended=next;audio.onerror=fail;
  audio.play().catch(fail);
 };
 next();
}
