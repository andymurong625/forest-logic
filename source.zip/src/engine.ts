import { kinds, type Kind, type Level, type Question } from './types';
import { bank, firstAdventure } from './data';
export type Skill={level:Level; independentStreak:number; demoStreak:number; played:number; independent:number; helped:number; skipped:number; last:number};
export type Session={ids:string[]; index:number; date:string; mode:'daily'|'free'; choiceOrder:string[]; selected:string[]; hint:number; mistakes:number; introduced:boolean; solved:boolean; recorded:boolean};
export type State={version:1; skills:Record<Kind,Skill>; seen:Kind[]; history:string[]; session:Session|null; completedDates:string[]; firstDone:boolean; sound:boolean; lastSummary:{date:string;kinds:Kind[]}|null};
export function initialState():State {return {version:1,skills:Object.fromEntries(kinds.map(k=>[k,{level:k==='pattern'||k==='classify'?2:1,independentStreak:0,demoStreak:0,played:0,independent:0,helped:0,skipped:0,last:0}])) as Record<Kind,Skill>,seen:[],history:[],session:null,completedDates:[],firstDone:false,sound:true,lastSummary:null};}
export function shuffle<T>(a:T[],random= Math.random):T[]{const out=a.slice();for(let i=out.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
export function isCorrect(q:Question,selection:string[]):boolean {if(selection.length!==q.answer.length||new Set(selection).size!==selection.length)return false;return q.mode==='order'?selection.every((id,i)=>id===q.answer[i]):selection.every(id=>q.answer.includes(id));}
export function record(state:State,q:Question,hint:number,mistakes:number,skip=false,now=Date.now()){
 const skill=state.skills[q.kind];skill.played++;skill.last=now;
 if(skip){skill.skipped++;skill.independentStreak=0;skill.demoStreak=0;}
 else if(hint===0&&mistakes===0){skill.independent++;skill.independentStreak++;skill.demoStreak=0;if(skill.independentStreak>=3){skill.level=Math.min(3,skill.level+1) as Level;skill.independentStreak=0;}}
 else {skill.helped++;skill.independentStreak=0;skill.demoStreak=hint>=3?skill.demoStreak+1:0;if(skill.demoStreak>=2){skill.level=Math.max(1,skill.level-1) as Level;skill.demoStreak=0;}}
 state.history=[...state.history.filter(x=>x!==q.id),q.id].slice(-100);
}
export function localDate(now=new Date()){return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;}
function choose(state:State,kind:Kind,exclude:string[],random:()=>number){const pool=bank.filter(q=>q.kind===kind&&q.level===state.skills[kind].level&&!exclude.includes(q.id));const fresh=pool.filter(q=>!state.history.includes(q.id));return shuffle(fresh.length?fresh:pool,random)[0].id;}
export function dailyIds(state:State,random=Math.random):string[]{if(!state.firstDone)return firstAdventure.slice();const chosen=shuffle(kinds.slice(),random).sort((a,b)=>state.skills[a].last-state.skills[b].last||state.skills[a].played-state.skills[b].played).slice(0,4);const order=[chosen[0],chosen[1],chosen[2],chosen[3],chosen[0],chosen[1]];const ids:string[]=[];order.forEach(k=>ids.push(choose(state,k,ids,random)));return ids;}
export function newSession(ids:string[],mode:'daily'|'free',date=localDate()):Session{return {ids,index:0,date,mode,choiceOrder:[],selected:[],hint:0,mistakes:0,introduced:false,solved:false,recorded:false};}
export function nextQuestion(s:Session){s.index++;s.choiceOrder=[];s.selected=[];s.hint=0;s.mistakes=0;s.introduced=false;s.solved=false;s.recorded=false;}
export function freeIds(state:State,kind:Kind,random=Math.random){const ids:string[]=[];for(let i=0;i<6;i++)ids.push(choose(state,kind,ids,random));return ids;}
export interface StorageLike {getItem(key:string):string|null;setItem(key:string,value:string):void;removeItem(key:string):void}
const KEY='forest-logic-v1';
export function saveState(storage:StorageLike,state:State){try{storage.setItem(KEY,JSON.stringify(state));return true;}catch{return false;}}
export function loadState(storage:StorageLike):{state:State;warning:string}{try{const raw=storage.getItem(KEY);if(!raw)return {state:initialState(),warning:''};const v=JSON.parse(raw) as State;
 if(v.version!==1||!Array.isArray(v.history)||!Array.isArray(v.seen)||!Array.isArray(v.completedDates)||typeof v.firstDone!=='boolean'||typeof v.sound!=='boolean'||!kinds.every(k=>v.skills?.[k]&&[1,2,3].includes(v.skills[k].level)&&['played','independent','helped','skipped','last','independentStreak','demoStreak'].every(key=>Number.isFinite((v.skills[k] as any)[key])&&(v.skills[k] as any)[key]>=0)))throw Error('invalid');
 if(v.session){const s=v.session;if(!['daily','free'].includes(s.mode)||!Array.isArray(s.ids)||s.ids.length!==6||s.ids.some(id=>!bank.some(q=>q.id===id))||!Number.isInteger(s.index)||s.index<0||s.index>6||!Array.isArray(s.choiceOrder)||!Array.isArray(s.selected)||!Number.isInteger(s.hint)||s.hint<0||s.hint>3)throw Error('invalid session');if(s.index<6){const q=bank.find(q=>q.id===s.ids[s.index])!;const validIds=q.choices.map(c=>c.id);if(s.selected.some(id=>!validIds.includes(id))||new Set(s.selected).size!==s.selected.length||s.choiceOrder.some(id=>!validIds.includes(id))||(s.choiceOrder.length>0&&(s.choiceOrder.length!==validIds.length||new Set(s.choiceOrder).size!==validIds.length))||!Number.isFinite(s.mistakes)||s.mistakes<0||typeof s.solved!=='boolean'||typeof s.recorded!=='boolean'||(s.solved&&!s.recorded))throw Error('invalid question state');}}
 return {state:v,warning:''};}catch{return {state:initialState(),warning:'无法读取本地进度，本次先从新的探险开始。请到家长区检查浏览器存储。'};}}
