import { type Choice, type Picture, type Question, type Level, type Kind } from './types';
import { colorNames } from './art';
const levels: Level[]=[1,2,3];
const shapeNames:Record<string,string>={circle:'圆形',square:'正方形',triangle:'三角形',star:'星形'};
const ch=(id:string,label:string,picture:Picture):Choice=>({id,label,picture});
const shape=(color:string,form='circle',detail?:string):Picture=>({icon:'shape',color,shape:form,detail});
const animalNames:Record<string,string>={rabbit:'小兔',cat:'小猫',bear:'小熊',elephant:'大象',giraffe:'长颈鹿',fish:'小鱼',bird:'小鸟',turtle:'乌龟',butterfly:'蝴蝶'};
const palette=['red','blue','yellow','green','purple','orange'];
export const bank:Question[]=[];
function add(kind:Kind,level:Level,index:number,q:Omit<Question,'id'|'kind'|'level'>){bank.push({id:`${kind}-${level}-${index}`,kind,level,...q});}
// Six curated subjects at each difficulty; silhouette comparison never relies on labels.
const shadowSubjects=['kettle','rabbit','cat','elephant','fish','butterfly'];
const objectNames:Record<string,string>={...animalNames,kettle:'水壶',cup:'杯子',umbrella:'雨伞',basket:'篮子'};
for(const level of levels)shadowSubjects.forEach((icon,i)=>{
 const near:Record<string,string[]>={kettle:['cup','basket','umbrella'],rabbit:['cat','bear','giraffe'],cat:['bear','rabbit','bird'],elephant:['bear','cat','rabbit'],fish:['bird','butterfly','turtle'],butterfly:['bird','fish','rabbit']};
 const candidates=[icon,...near[icon]].slice(0,level===1?3:4);
 add('shadow',level,i,{title:level===1?'找到对应的影子':'轮廓小侦探',prompt:level===1?`哪个东西和这个影子一样呢？`:`哪个影子属于${objectNames[icon]}？`,mode:'pick',reference:{icon,shadow:level===1,color:'orange'},choices:candidates.map((a,j)=>ch(`s${j}`,objectNames[a],{icon:a,color:palette[j],shadow:level!==1,flip:level===3})),answer:['s0'],hints:[`看看${icon==='rabbit'?'长长的耳朵':icon==='elephant'?'长长的鼻子':icon==='fish'?'尾巴':icon==='kettle'?'壶嘴和把手':icon==='cat'?'尖耳朵和尾巴':'两边的翅膀'}。`,'沿着外边的线看一看，颜色不影响轮廓。',`亮起来的${objectNames[icon]}，轮廓和图中一样。`],explanation:`找到了！它们的外形一样${level===3?'，只是朝向变了':''}。`,demo:'看看中间的图，再点一下对应的图片。'});
});
const opposites=[
 {icon:'umbrella',a:'open',b:'closed',an:'打开',bn:'合上',color:'yellow'},
 {icon:'door',a:'open',b:'closed',an:'打开',bn:'关上',color:'green'},
 {icon:'box',a:'open',b:'closed',an:'打开',bn:'盖好',color:'orange'},
 {icon:'lamp',a:'on',b:'off',an:'亮着',bn:'熄灭',color:'yellow'},
 {icon:'shape',a:'large',b:'small',an:'大',bn:'小',color:'blue'},
 {icon:'arrow',a:'up',b:'down',an:'向上',bn:'向下',color:'purple'}
];
for(const level of levels)opposites.forEach((o,i)=>{
 const reverse=level===2;const a=reverse?o.b:o.a,b=reverse?o.a:o.b,an=reverse?o.bn:o.an,bn=reverse?o.an:o.bn;
 const noun=({umbrella:'伞',door:'门',box:'盒子',lamp:'灯',shape:'圆',arrow:'箭头'} as Record<string,string>)[o.icon];
 const pic=(detail:string,color=o.color):Picture=>({icon:o.icon,detail,color,shape:'circle'});
 const choices=[ch('opposite',bn,pic(b)),ch('same',an,pic(a)),ch('other',`${an}的另一个${noun}`,pic(a,palette[(i+2)%6]))];
 if(level===3) choices.push(ch('another',`${an}的另一个${noun}`,pic(a,palette[(i+3)%6])));
 add('opposite',level,i,{title:'找另一种样子',prompt:`这${o.icon==='shape'?'个':'个'}${noun}是${an}的。请找到${bn}的${noun}。`,reference:pic(a),mode:'pick',choices,answer:['opposite'],hints:[`先看看${noun}现在的样子。`,`我们要找${bn}的，不用看颜色。`,`亮起来的${noun}是${bn}的。`],explanation:`${an}和${bn}，是一对相反的样子。`,demo:'看上面的图片，听一听，再点出相反的样子。'});
});
const animalSeeds=[
 {icon:'rabbit',trait:'长长的耳朵',extra:'短短的尾巴',hint:'看看头顶，两只耳朵长长的。',others:['cat','bear','turtle']},
 {icon:'elephant',trait:'长长的鼻子',extra:'大大的耳朵',hint:'找一找能弯起来的长鼻子。',others:['bear','cat','fish']},
 {icon:'giraffe',trait:'长长的脖子',extra:'脖子上的斑点',hint:'看看谁的头离身体很远。',others:['rabbit','cat','turtle']},
 {icon:'fish',trait:'鱼鳍',extra:'扇形的尾巴',hint:'它的身体两边没有腿，用鱼鳍游泳。',others:['bird','turtle','butterfly']},
 {icon:'turtle',trait:'背上的硬壳',extra:'四条短腿',hint:'看看谁背着圆圆的壳。',others:['fish','cat','rabbit']},
 {icon:'bird',trait:'尖尖的鸟嘴',extra:'羽毛覆盖的翅膀',hint:'看看谁有鸟嘴和两条细腿。',others:['butterfly','rabbit','fish']}
];
for(const level of levels)animalSeeds.forEach((a,i)=>{
 const prompt=level===1?`谁有${a.trait}？`:level===2?`找到有${a.trait}，还有${a.extra}的动物。`:`我有${a.trait}，也有${a.extra}。我是谁？`;
 add('animal',level,i,{title:'认识森林朋友',prompt,mode:'pick',choices:[a.icon,...a.others].slice(0,level===1?3:4).map((icon,j)=>ch(icon,animalNames[icon],{icon,color:['orange','green','blue','yellow'][j]})),answer:[a.icon],hints:[a.hint,`仔细看看每只动物的身体，找${a.trait}。`,`这就是${animalNames[a.icon]}，它有${a.trait}。`],explanation:`对啦，${animalNames[a.icon]}有${a.trait}。`,demo:'听听动物的特征，再点一下你找到的朋友。'});
});
for(const level of levels)for(let i=0;i<6;i++){
 const a=palette[i],b=(level===2&&i===2)?'blue':palette[(i+1)%6],c=palette[(i+2)%6];
 const unit=level===1?[a,b]:level===2?[a,a,b]:[a,b,b];
 const seq=[...unit,...unit];const missing=level===3?4:seq.length-1;const answer=seq[missing];
 add('pattern',level,i,{title:level===3?'修好彩色路标':'颜色排排队',prompt:level===3?'这里少了一面旗子，帮我补上吧。':'看看颜色是怎么排队的，空着的位置是什么颜色？',mode:'pick',strip:seq.map((color,j)=>j===missing?null:shape(color,level===3?'triangle':'circle')),choices:[a,b,c].map(color=>ch(color,colorNames[color],shape(color,level===3?'triangle':'circle'))),answer:[answer],hints:['从左到右，看一看颜色的顺序。',`每一组都是：${unit.map(x=>colorNames[x]).join('、')}。`,`空着的地方应该是${colorNames[answer]}。`],explanation:`对啦！${unit.map(x=>colorNames[x]).join('、')}，一组一组重复。`,demo:'从左向右观察，再点下面的颜色，补进问号里。'});
}
const forms=['circle','triangle','square'];
for(const level of levels)for(let i=0;i<6;i++){
 const color=palette[i],other=palette[(i+1)%6],form=forms[i%3],otherForm=forms[(i+1)%3];
 let pics:Picture[], answer:string[],prompt:string;
 if(level===1){pics=[shape(color,form),shape(other,form),shape(color,otherForm),shape(other,otherForm)];answer=['c0','c2'];prompt=`把所有${colorNames[color]}的物品放进篮子。`;}
 else if(level===2){pics=[shape(color,form),shape(other,form),shape(color,otherForm),shape(color,form,'dot')];answer=['c0','c3'];prompt=`把所有${colorNames[color]}的${shapeNames[form]}放进篮子。`;}
 else {pics=[shape(color,form),shape(other,form),shape(color,otherForm),shape(other,otherForm)];answer=['c0','c1'];prompt=`这次只按形状整理。把所有${shapeNames[form]}放进篮子，不管是什么颜色。`;}
 add('classify',level,i,{title:level===3?'换个办法整理':'小小整理师',prompt,mode:'collect',choices:pics.map((p,j)=>ch(`c${j}`,`${colorNames[p.color!]}${shapeNames[p.shape!]}`,p)),answer,hints:[level===1?'先看物品的颜色。':level===2?`先找${colorNames[color]}，再看形状。`:'这次颜色不重要，只看形状。',level===2?`要同时是${colorNames[color]}，又是${shapeNames[form]}。`:`符合要求的都要找出来，一共有两个。`,'看，亮起来的两个都符合要求。点物品，再点篮子。'],explanation:level===2?`它们都是${colorNames[color]}的${shapeNames[form]}！`:'你把符合要求的物品都找到了！',demo:'先点一个物品，再点篮子；也可以把物品拖进篮子。找齐后点“整理好了”。'});
}
const stories=[
 {title:'种一朵花',steps:['seed','water','sprout','bloom'],names:['种下种子','浇水','长出嫩芽','开花'],why:'种下种子，浇水，嫩芽长大后才会开花。'},
 {title:'洗干净小手',steps:['wash-dirty','wash-soap','wash-rinse','wash-clean'],names:['手上有污渍','抹上肥皂','用水冲洗','洗干净了'],why:'先抹肥皂，再冲掉泡沫，小手就干净了。'},
 {title:'搭积木',steps:['blocks1','blocks2','blocks3','blocks4'],names:['第一块积木','两块做底座','加上第三块','加上第四块'],why:'先搭下面的底座，再一块一块向上搭。'},
 {title:'吃苹果',steps:['apple-tree','apple-wash','apple-cut','apple-eaten'],names:['苹果长在树上','洗苹果','切开苹果','吃苹果'],why:'苹果摘下来，先洗干净，再由大人切开，最后吃。'},
 {title:'堆雪人',steps:['snow1','snow2','snow3','snow4'],names:['堆好身体','放上脑袋','装上眼睛鼻子','戴上帽子围巾'],why:'先堆身体和脑袋，再装五官，最后戴帽子和围巾。'},
 {title:'蝴蝶长大了',steps:['life-egg','life-caterpillar','life-chrysalis','life-butterfly'],names:['小小的卵','毛毛虫','变成蛹','变成蝴蝶'],why:'蝴蝶从卵开始，长成毛毛虫，再变成蛹，最后变成蝴蝶。'}
];
for(const level of levels)stories.forEach((s,i)=>{
 const indices=level===1?[0,1,3]:[0,1,2,3];
 const reversed=level===3;
 const answer=indices.map(x=>`step${x}`);if(reversed)answer.reverse();
 add('sequence',level,i,{title:s.title,prompt:reversed?`我们来倒着回想“${s.title}”：从最后发生的开始排。`:`“${s.title}”先做什么，再做什么？按顺序排好图片。`,mode:'order',choices:indices.map(x=>ch(`step${x}`,s.names[x],{icon:'scene',detail:s.steps[x]})),answer,hints:[reversed?'先找最后完成的样子。':'先找事情刚开始的样子。',`第一张应该是“${s.names[Number(answer[0].slice(4))]}”。`,`看，图片依次亮起：${answer.map(x=>s.names[Number(x.slice(4))]).join('，')}。`],explanation:s.why,demo:'按顺序点击图片，它们会排到上面。点已排好的图片可以撤回。排好后点“排好了”。'});
});
for(const level of levels)for(let i=0;i<6;i++){
 const color=palette[i],other=palette[(i+1)%6],form=forms[i%3],differentForm=forms[(i+1)%3];
 const pics=level===1?[shape(color,form),shape(color,form),shape(other,form)]:level===2?[shape(color,form),shape(color,form),shape(color,differentForm),shape(color,form)]:[shape(color,form,'dot'),shape(color,form,'dot'),shape(color,form),shape(color,form,'dot')];
 const attr=level===1?'颜色':level===2?'形状':'中间的小圆点';
 add('different',level,i,{title:'发现小小不同',prompt:`仔细看看${attr}，哪一个和其他的不一样？`,mode:'pick',choices:pics.map((p,j)=>ch(`d${j}`,`第${j+1}个图形`,p)),answer:['d2'],hints:[`这次只比较${attr}。`,level===3?'其他图形的中间都有一个小圆点。':`其他图形都是${level===1?colorNames[color]:shapeNames[form]}。`,'亮起来的这个，和其他图形不一样。'],explanation:level===3?'找到了！它的中间没有小圆点。':`找到了！这个的${attr}不一样。`,demo:'仔细比较图片，点出和其他不同的那个。'});
}
for(const level of levels)for(let i=0;i<6;i++){
 const a=palette[i],b=palette[(i+1)%6],c=palette[(i+2)%6];
 const pics:Picture[]=level===1?[{icon:'house',color:a},{icon:'house',color:b}]:level===2?[{icon:'house',color:a},{icon:'house',color:b},{icon:'house',color:c}]:[{icon:'house',color:a,shape:'triangle'},{icon:'house',color:a,shape:'square'},{icon:'house',color:b,shape:'triangle'},{icon:'house',color:b,shape:'square'}];
 const prompt=level===1?`小兔不住${colorNames[a]}的房子。它住哪里？`:level===2?`小兔不住${colorNames[a]}的房子，也不住${colorNames[b]}的房子。它住哪里？`:`小兔住${colorNames[a]}的房子，而且屋顶是三角形。帮它找到家。`;
 const target=level===1?'h1':level===2?'h2':'h0';
 add('reason',level,i,{title:'跟着线索找家',prompt,mode:'pick',choices:pics.map((p,j)=>ch(`h${j}`,`${colorNames[p.color!]}房子${level===3?(p.shape==='square'?'，平屋顶':'，三角屋顶'):''}`,p)),answer:[target],hints:[level===3?`先找${colorNames[a]}的房子。`:`先排除${colorNames[a]}的房子。`,level===3?'再看看屋顶，要三角形的。':level===2?`再排除${colorNames[b]}的房子。`:'只剩下一座房子啦。',`亮起来的房子符合全部线索。`],explanation:level===3?'颜色和屋顶都符合，小兔到家啦！':'排除不符合的，剩下的就是小兔的家！',demo:'听完所有线索，再点一下符合条件的房子。'});
}
export const firstAdventure=['shadow-1-0','classify-2-0','pattern-2-2','opposite-1-0','shadow-2-1','pattern-3-0'];
export const questionById=(id:string)=>bank.find(q=>q.id===id)!;
